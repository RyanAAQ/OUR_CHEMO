package ng.ourChemo.data.repositories;

import ng.ourChemo.data.models.DispensedDrugs;

public class DispensedDrugsImpl extends DispensedDrugs {
}
